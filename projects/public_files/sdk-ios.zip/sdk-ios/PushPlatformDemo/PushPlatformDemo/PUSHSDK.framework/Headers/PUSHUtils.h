//
//  PUSHUtils.h
//  PUSHSDK
//
//  Created by 兴朝 王 on 15/11/2.
//  Copyright © 2015年 com.autohome. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UIApplication;

@interface PUSHUtils : NSObject

//在AppDelegate的didFinishLaunchingWithOptions中注册push通知
+ (void)registerNotification:(UIApplication *)application;

//获取到Token信息，并且上传到远程服务器端
- (void)getTokenAndRemoteServer:(NSData *)deviceToken appId:(NSString *)appId domain:(NSString *)domain;


@end
