//
//  PUSHSDK.h
//  PUSHSDK
//
//  Created by 兴朝 王 on 15/11/2.
//  Copyright © 2015年 com.autohome. All rights reserved.
//

#import <UIKit/UIKit.h>

#define API_DOMAIN (@"http://ch.selcome.com/api/user/updateUserInfo")

#import "PUSHUtils.h"



