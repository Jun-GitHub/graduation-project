//
//  AppDelegate.m
//  PushPlatformDemo
//
//  Created by 兴朝 王 on 15/11/2.
//  Copyright © 2015年 com.autohome. All rights reserved.
//

#import "AppDelegate.h"
#import <PUSHSDK/PUSHSDK.h>

@interface AppDelegate ()
{

}
@property (nonatomic, strong) PUSHUtils *pushUtils;
@end

@implementation AppDelegate
@synthesize pushUtils;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    //注册远程通知
    [PUSHUtils registerNotification:application];
    pushUtils = [[PUSHUtils alloc] init];

    return YES;
}

- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString *domain = @"http://ch.selcome.com/api/user/updateUserInfo";
    [pushUtils getTokenAndRemoteServer:deviceToken appId:@"1448255507170" domain:domain];
}

//注册push功能失败 后 返回错误信息，执行相应的处理
- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err
{
    NSLog(@"Push Register Error:%@", err.description);
}

- (void)applicationWillResignActive:(UIApplication *)application {

}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
