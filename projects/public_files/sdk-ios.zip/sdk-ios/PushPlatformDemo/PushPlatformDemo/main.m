//
//  main.m
//  PushPlatformDemo
//
//  Created by 兴朝 王 on 15/11/2.
//  Copyright © 2015年 com.autohome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
